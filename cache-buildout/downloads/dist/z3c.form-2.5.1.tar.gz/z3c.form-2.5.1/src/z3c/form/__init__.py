# Make a package.

# Apply compatibility layer
from z3c.form import compatibility
compatibility.apply()
del compatibility