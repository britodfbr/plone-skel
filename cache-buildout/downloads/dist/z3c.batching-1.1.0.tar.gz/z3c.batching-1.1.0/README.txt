This package provides simple sequence batching.
