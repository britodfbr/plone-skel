Scaling
=======

.. module:: plone.scale.scale
   :synopsis: Image scaling routines

This module contains functions to scale images in particular ways. The
functions operate on raw image data and have no Zope dependencies.

Functions
---------

.. autofunction:: scaleImage

