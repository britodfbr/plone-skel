PROJECTNAME = 'plone.app.kss'
SKINS_DIR = 'skins'

GLOBALS = globals()
