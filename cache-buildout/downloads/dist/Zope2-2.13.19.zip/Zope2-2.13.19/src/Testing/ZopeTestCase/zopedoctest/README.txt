Doc test support for ZopeTestCase
=================================

Backport of functional doc tests from Zope 3 by
Sidnei da Silva. See 'FunctionalDocTest.txt' for
documentation.

You can learn more about doc tests here:
http://docs.python.org/lib/module-doctest.html

