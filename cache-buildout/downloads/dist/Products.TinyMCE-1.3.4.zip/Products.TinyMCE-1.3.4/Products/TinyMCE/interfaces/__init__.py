from zope.interface import Interface

class ITinyMCECompressor(Interface):
    """ A marker for the TinyMCE compressor """
