Installation
============

Latest version
--------------

- Add Products.TinyMCE in your buildout.cfg to the eggs attributes
- Run buildout and (re)start Zope
- Use the quick installer to (re)install the product

For basic installation use the following section in your buildout::

    [buildout]
    ...
    eggs =
        ...
        Products.TinyMCE

Development version
-------------------

Please refer to :ref:`developer-manual`, it is really important to read and understand the whole section.
