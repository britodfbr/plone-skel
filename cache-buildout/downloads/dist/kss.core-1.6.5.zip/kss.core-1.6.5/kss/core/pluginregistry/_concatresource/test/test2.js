/* A 2nd js file */

/*
*
*
*
*/

var someContents = "Some content here, too.";
var someMoreContents = "Some more content.";
