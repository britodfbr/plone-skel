
/* At the moment, there is no javascript, and
 * switching is done from the server side.
 */

