from Products.ATContentTypes.interfaces.interfaces import IATContentType


class IATEvent(IATContentType):
    """AT Event marker interface
    """
