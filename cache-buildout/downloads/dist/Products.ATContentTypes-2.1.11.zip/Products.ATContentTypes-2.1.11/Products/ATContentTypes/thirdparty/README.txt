Third party extensions
======================

This directory contains additional third party python modules and package
required by ATContentTypes. Third party extensions might be covered by
a different license.

The thirdparty directory is inserted into sys.path after the instance and
zope lib/python directories. You can copy or symlink python packages to 
your instance home's lib/python directory in order to overwrite the python
modules and packages in this directory.
