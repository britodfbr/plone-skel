from Products.PloneTestCase.layer import PloneSite


class PlonePASLayer(PloneSite):

    @classmethod
    def setUp(cls):
        pass

    @classmethod
    def tearDown(cls):
        pass
