This is designed to be more of a reference than the procedural
documentation in the folder above.

It's currently only just beginning, so please feel free to submit
patches, comments and suggestions to kupu-dev@codespeak.net.

The files are as follows:

errors.txt

  - A list of the errors commonly emitted by Kupu and the common ways
    to solve them.

glossary.txt

  - A glossary of the terms you're likely to encounter when dealing
    with Kupu.

kupuconfig.txt

  - This is a reference for the various sections that can be set in
    the <kupuconfig> xml block at the top of your editing template. 