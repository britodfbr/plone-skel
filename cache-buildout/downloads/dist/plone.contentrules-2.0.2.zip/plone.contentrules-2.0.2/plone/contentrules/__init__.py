from zope.i18nmessageid import MessageFactory

PloneMessageFactory = MessageFactory('plone')
