from plone.portlet.collection.collection import Assignment as AliasedAssignment


# for backwards-compatibility with old pickles
Assignment = AliasedAssignment
