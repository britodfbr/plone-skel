NOTE: this package is deprecated. Its functionality has been moved to
more reusable packages, namely: zope.component, zope.security, zope.site
and zope.componentvocabulary. Please import from there instead.

This package provides various ZCML directives (view, resource) and a
user interface related to local component management.
