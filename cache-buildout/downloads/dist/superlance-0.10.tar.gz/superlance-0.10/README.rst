superlance README
=================

Superlance is a package of plugin utilities for monitoring and controlling
processes that run under `supervisor <http://supervisord.org>`_.

Please see ``docs/index.rst`` for complete documentation.
