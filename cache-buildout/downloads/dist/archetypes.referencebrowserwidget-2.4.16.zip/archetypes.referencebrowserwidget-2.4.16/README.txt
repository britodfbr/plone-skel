Introduction
************

This is an implementation of  referencebrowser widget. It
provides a widget used for Archetypes reference-fields. The widget can
be used on its own or as a dropin replacement of the ATReferenceBrowserWidget
in Plone 3 and is included in Plone >= 4.
Unlike the ATReferenceBrowserWidget, archetypes.refencebrowserwidget uses
an overlay instead of a popup to display the referencebrowser.

Versions
========

Version 1 of the product is a classical popup and works with Plone 3 and 4.
Version 2 of the product displays the browser as a jQuery overlay. Currently
it is only tested with Plone 4.
