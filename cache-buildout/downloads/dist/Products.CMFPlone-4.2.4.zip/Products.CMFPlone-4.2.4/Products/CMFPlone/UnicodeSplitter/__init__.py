# -*- coding: utf-8 -*-
"""
__init__.py

Created by Manabu Terada, CMScom on 2009-09-30.
"""
from splitter import *
