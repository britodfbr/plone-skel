from zope.interface import Interface


class MarkerInterface(Interface):
    pass
