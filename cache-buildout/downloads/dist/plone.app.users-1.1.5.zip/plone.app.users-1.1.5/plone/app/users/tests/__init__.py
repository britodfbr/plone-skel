# Other packages may find this useful

from plone.app.users.tests.base import TestCase

