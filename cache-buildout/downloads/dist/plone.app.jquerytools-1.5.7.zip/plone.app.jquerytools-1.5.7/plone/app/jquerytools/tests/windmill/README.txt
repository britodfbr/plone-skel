Windmill browser integration tests

Use:

bin/test -s plone.app.jquerytools --tests-pattern=windmill

Beware: these tests may move or be renamed.