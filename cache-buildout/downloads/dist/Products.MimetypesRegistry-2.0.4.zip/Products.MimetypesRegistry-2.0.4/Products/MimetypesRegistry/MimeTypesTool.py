# backward compatibility
from Products.MimetypesRegistry.MimeTypesRegistry import MimeTypesRegistry as MimeTypesTool
