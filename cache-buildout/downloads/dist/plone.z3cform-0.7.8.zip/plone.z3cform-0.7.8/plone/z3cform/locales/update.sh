i18ndude rebuild-pot --pot plone.z3cform.pot --create plone.z3cform ../
i18ndude sync --pot plone.z3cform.pot ./*/LC_MESSAGES/plone.z3cform.po
