Selenium 2 integration tests for Search results view

Use:

bin/test -s plone.app.search --tests-pattern=selenium

Beware: these tests may move or be renamed.