Five tests
==========

All you have to do is type::

  $ bin/zopectl test -s Products.Five

to run the Five tests.
