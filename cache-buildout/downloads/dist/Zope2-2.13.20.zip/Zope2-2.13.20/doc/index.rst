
Zope 2.13 specific documentation
================================

.. Note::

    The Zope 2.13.x release series is in bug-fix-only mode. It will see
    security and bug fixes until further notice.

Contents:

.. toctree::
   :maxdepth: 2

   WHATSNEW.rst
   INSTALL.rst
   INSTALL-buildout.rst
   operation.rst
   USERS.rst
   SECURITY.rst
   SETUID.rst
   SIGNALS.rst
   DEBUGGING.rst
   CHANGES.rst

