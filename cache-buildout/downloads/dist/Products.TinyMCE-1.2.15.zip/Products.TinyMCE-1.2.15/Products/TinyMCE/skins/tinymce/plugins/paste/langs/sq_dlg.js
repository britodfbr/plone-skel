tinyMCE.addI18n('sq.paste_dlg',{
text_title:"P\u00EBrdor CTRL+V p\u00EBr t\u00EB ngjitur tekstin.",
text_linebreaks:"Ruaj linjat e reja",
word_title:"P\u00EBrdor CTRL+V p\u00EBr t\u00EB ngjitur tekstin."
});