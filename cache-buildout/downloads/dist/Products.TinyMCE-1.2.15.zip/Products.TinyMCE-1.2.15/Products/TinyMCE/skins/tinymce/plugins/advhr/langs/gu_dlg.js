tinyMCE.addI18n('gu.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});