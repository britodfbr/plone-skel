tinyMCE.addI18n('az.paste_dlg',{
text_title:"P\u0259nc\u0259r\u0259y\u0259 m\u0259tn \u0259lav\u0259 etm\u0259k \u00FC\u00E7\u00FCn CTRL+V klavi\u015F birl\u0259\u015Fm\u0259sini istifad\u0259 edin.",
text_linebreaks:"S\u0259tr s\u0131nmalar\u0131n\u0131 saxla",
word_title:"P\u0259nc\u0259r\u0259y\u0259 s\u00F6z \u0259lav\u0259 etm\u0259k \u00FC\u00E7\u00FCn CTRL+V klavi\u015F birl\u0259\u015Fm\u0259sini istifad\u0259 edin."
});