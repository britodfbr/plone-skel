tinyMCE.addI18n('ms.advhr_dlg',{
width:"Lebar",
size:"Tinggi",
noshade:"Tanpa bayang"
});