tinyMCE.addI18n('lt.advhr_dlg',{
width:"Ilgis",
size:"Auk\u0161tis",
noshade:"Be \u0161e\u0161\u0117lio"
});