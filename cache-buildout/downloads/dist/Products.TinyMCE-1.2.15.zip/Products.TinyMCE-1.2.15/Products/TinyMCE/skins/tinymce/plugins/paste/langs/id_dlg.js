tinyMCE.addI18n('id.paste_dlg',{
text_title:"Gunakan CTRL+V pada keyboard untuk paste.",
text_linebreaks:"Keep linebreaks",
word_title:"Gunakan CTRL+V pada keyboard untuk paste."
});