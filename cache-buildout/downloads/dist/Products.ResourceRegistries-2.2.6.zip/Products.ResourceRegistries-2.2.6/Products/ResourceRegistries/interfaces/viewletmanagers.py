from zope.viewlet.interfaces import IViewletManager

class IHtmlHeadScripts(IViewletManager):
    """ A viewlet manager for javascripts. """

class IHtmlHeadStyles(IViewletManager):
    """ A viewlet manager for stylesheets. """
