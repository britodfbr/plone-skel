from Products.ResourceRegistries.tools.packer import test_suite

