Creating a simple form
=======================

.. toctree::
   :maxdepth: 2

   creating-a-package.rst
   creating-a-schema.rst
   creating-the-form-view.rst
   testing-the-form.rst
