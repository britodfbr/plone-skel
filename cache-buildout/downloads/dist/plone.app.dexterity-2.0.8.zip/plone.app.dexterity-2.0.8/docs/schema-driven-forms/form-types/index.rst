Form types
===========

.. toctree::
   :maxdepth: 2

   base-forms-and-schema-forms.rst
   page-forms.rst
   add-forms.rst
   edit-forms.rst
   display-forms.rst
