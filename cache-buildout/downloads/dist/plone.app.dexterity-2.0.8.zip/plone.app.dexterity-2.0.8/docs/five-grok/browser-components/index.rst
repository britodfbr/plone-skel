Browser components
==================================================

**Using five.grok to create views, viewlets and resource directories**

.. toctree::
   :maxdepth: 2

   views.rst
   viewlets.rst
   resource-directories.rst
