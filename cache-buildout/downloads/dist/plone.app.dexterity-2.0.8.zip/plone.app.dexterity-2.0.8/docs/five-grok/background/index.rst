Background
==================================================

**What is five.grok all about?**

.. toctree::
   :maxdepth: 2

   the-zope-component-architecture.rst
   what-is-grok-and-five-grok.rst
   adding-five-grok-as-a-dependency.rst
