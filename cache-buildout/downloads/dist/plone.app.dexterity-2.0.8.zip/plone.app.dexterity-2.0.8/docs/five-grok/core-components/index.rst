Core components
==================================================

**Using five.grok to configure adapters, utilities and event subscribers**

.. toctree::
   :maxdepth: 2

   interfaces.rst
   utilities.rst
   adapters.rst
   annotations.rst
   events.rst
   further-details.rst
