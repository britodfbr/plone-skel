from zope.i18nmessageid import MessageFactory
SchemaEditorMessageFactory = MessageFactory('plone.schemaeditor')
