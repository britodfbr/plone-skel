Overview
========

This package contains the upgrade machinery to upgrade a Plone site to a
newer version.
