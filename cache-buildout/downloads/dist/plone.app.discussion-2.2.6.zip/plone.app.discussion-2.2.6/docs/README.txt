For developers documentation on plone.app.discussion, see 
http://packages.python.org/plone.app.discussion.