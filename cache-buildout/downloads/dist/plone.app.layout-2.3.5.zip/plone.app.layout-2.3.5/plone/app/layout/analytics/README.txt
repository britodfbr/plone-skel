Analytics package
-----------------

This package adds a viewlet to the portal footer which gets filled with 
javascript code for any analytics package as e.g. Google Analytics.

The contents of viewlet come from site_properties/webstats_js and this in turn
gets edited in the control panel.

