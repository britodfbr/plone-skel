Introduction
============

plone.app.contentmenu contains the logic that powers Plone's content menu
(the green one with the drop-down menus).

