Directory 'skins/FAQ':

This skin layer has low priority, put unique templates and scripts here.

I.e. if you to want to create own unique views or forms for your product, this
is the right place.
