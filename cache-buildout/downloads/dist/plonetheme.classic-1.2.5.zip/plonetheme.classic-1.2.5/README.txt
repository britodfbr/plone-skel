Introduction
============

This theme implements the look of Plone 3 and earlier in a separate package, 
and is supplied for backwards compatibility reasons, and for people who prefer
the old theme over the new standard one in Plone 4.

