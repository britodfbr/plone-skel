This package provides a caching mechanism for Zope applications.
